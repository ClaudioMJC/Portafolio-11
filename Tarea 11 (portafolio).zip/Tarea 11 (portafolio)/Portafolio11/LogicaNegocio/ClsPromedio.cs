﻿using System;

namespace LogicaNegocio
{
    public class ClsPromedio
    {   //atributos
        private string condicion;
        private string color;
        private double promedio;
        //getters and setters
        public string Condicion { get => condicion; set => condicion = value; }
        public string Color { get => color; set => color = value; }
        public double Promedio { get => promedio; set => promedio = value; }

        public ClsPromedio() { }

        public void calcularPromedio(double sumaNotas, int cantidadNotas)
        {
            promedio = sumaNotas / cantidadNotas;
        }

        public void calcularCondicion(double promedio) {
            if (promedio>=70)
            {
                condicion = "Aprobado";
                color = "verde";
            }   
            else
            {
                condicion = "reprobado";
                color = "rojo";
            }  
        }
        
        public double calcularPromedio(double v1, object sumaNotas, int v2, object cantidadNotas)
        {
            throw new NotImplementedException();
        }

        public void calcularCondicion(ClsPromedio promedioCalculadora)
        {
            throw new NotImplementedException();
        }

        public void calcularCondicion(string condicion)
        {
            throw new NotImplementedException();
        }

        /*public double calcularPromedio(double suma)
        {
            throw new NotImplementedException();
        }
        */
    }
}
