﻿using LogicaNegocio;
using System;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProyectoEscritorio
{
    public partial class Frm_RegistroNotas : Form
    {
        private double sumaNotas;
        private object cantidadNotas;

        public Frm_RegistroNotas()
        {
            InitializeComponent();
        }

        public void btn_Salir_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void borrarPromedio()
        {
            lbl_Promedio.Text = "";
            lbl_Promedio.BackColor = SystemColors.Info;
        }

        public static double totalSumaNotas(System.Windows.Forms.ListView.ListViewItemCollection Lista_Notas) //static devuelve algo
        {
            double suma = 0;

            if (Lista_Notas.Count > 0)
            {
                // Realizar la suma de los elementos de la lista
                foreach (ListViewItem item in Lista_Notas)
                {
                    // Suponiendo que los valores a sumar se encuentran en subítems de cada ListViewItem
                    suma += double.Parse(item.SubItems[0].Text);
                }
            }
            return suma;
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            string nota = txtNota.Text;
            if (string.IsNullOrEmpty(nota))  //primer if verifica si ingresó una nota
            {
                MessageBox.Show("Debe ingresar una nota", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!double.TryParse(nota, out double numero)) //verifica que si no es un valor númerico
            {
                MessageBox.Show("Debe ingresar un valor númerico", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNota.Text = string.Empty;
                return;
            }
            if (numero > 100) //Que no sea una nota mayor a 100
            {
                MessageBox.Show("Debe ingresar un valor menor o igual a 100", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNota.Text = string.Empty;
                return;
            }
            //es una nota válida y se ingresa a la lista
            lista_Notas.Items.Add(nota.ToString());
            borrarPromedio();
            txtNota.Text = string.Empty;


        }


        private void lista_Notas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lista_Notas.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lista_Notas.SelectedItems[0];
                string notaSeleccionada = selectedItem.SubItems[0].Text;
                txt_NotaSeleccionada.Text = notaSeleccionada;
            }
        }

        private void btn_EliminarSelec_Click(object sender, EventArgs e)
        {
            if (lista_Notas.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lista_Notas.SelectedItems[0];
                lista_Notas.Items.Remove(selectedItem);
                txt_NotaSeleccionada.Clear();
                borrarPromedio();
            }
            else
            {
                MessageBox.Show("Seleccione una nota antes de eliminar.", "Nota no seleccionada", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_ListaNotas_Click(object sender, EventArgs e)
        {
            lista_Notas.Items.Clear();
            txt_NotaSeleccionada.Clear();
            txt_NotaSeleccionada.Clear();
            borrarPromedio();
        }

        private void btn_Resultado_Click(object sender, EventArgs e)
        {
            if (lista_Notas.Items.Count == 0)
            {
                MessageBox.Show("No hay notas registradas para calcular el promedio.", "Sin notas", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                double suma = totalSumaNotas(lista_Notas.Items);
                int cantidadNotas = lista_Notas.Items.Count;

                ClsPromedio promedioCalculadora = new ClsPromedio();
                promedioCalculadora.calcularPromedio(suma, cantidadNotas);
                promedioCalculadora.calcularCondicion(promedioCalculadora.Condicion);

                lbl_Promedio.BackColor = SystemColors.Info;
                lbl_Promedio.Text = $"Promedio: {promedioCalculadora.Promedio} - {promedioCalculadora.Condicion}";
            }
        }
    }
}
