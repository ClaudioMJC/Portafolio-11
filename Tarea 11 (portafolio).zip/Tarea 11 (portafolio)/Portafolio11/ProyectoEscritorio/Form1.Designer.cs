﻿namespace ProyectoEscritorio
{
    partial class Frm_RegistroNotas
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new System.Windows.Forms.GroupBox();
            lista_Notas = new System.Windows.Forms.ListView();
            lbl_Promedio = new System.Windows.Forms.Label();
            btn_Resultado = new System.Windows.Forms.Button();
            btn_ListaNotas = new System.Windows.Forms.Button();
            btn_EliminarSelec = new System.Windows.Forms.Button();
            txt_NotaSeleccionada = new System.Windows.Forms.TextBox();
            lbl_NotasSelec = new System.Windows.Forms.Label();
            btn_Add = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            txtNota = new System.Windows.Forms.TextBox();
            btn_Salir = new System.Windows.Forms.Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lista_Notas);
            groupBox1.Controls.Add(lbl_Promedio);
            groupBox1.Controls.Add(btn_Resultado);
            groupBox1.Controls.Add(btn_ListaNotas);
            groupBox1.Controls.Add(btn_EliminarSelec);
            groupBox1.Controls.Add(txt_NotaSeleccionada);
            groupBox1.Controls.Add(lbl_NotasSelec);
            groupBox1.Controls.Add(btn_Add);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtNota);
            groupBox1.Location = new System.Drawing.Point(25, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(738, 470);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Registro de Notas";
            // 
            // lista_Notas
            // 
            lista_Notas.HideSelection = false;
            lista_Notas.Location = new System.Drawing.Point(496, 45);
            lista_Notas.Name = "lista_Notas";
            lista_Notas.Size = new System.Drawing.Size(199, 354);
            lista_Notas.TabIndex = 11;
            lista_Notas.UseCompatibleStateImageBehavior = false;
            lista_Notas.SelectedIndexChanged += lista_Notas_SelectedIndexChanged;
            // 
            // lbl_Promedio
            // 
            lbl_Promedio.BackColor = System.Drawing.SystemColors.Window;
            lbl_Promedio.Location = new System.Drawing.Point(20, 351);
            lbl_Promedio.Name = "lbl_Promedio";
            lbl_Promedio.Size = new System.Drawing.Size(433, 91);
            lbl_Promedio.TabIndex = 10;
            // 
            // btn_Resultado
            // 
            btn_Resultado.Location = new System.Drawing.Point(294, 286);
            btn_Resultado.Name = "btn_Resultado";
            btn_Resultado.Size = new System.Drawing.Size(159, 34);
            btn_Resultado.TabIndex = 9;
            btn_Resultado.Text = "&Ver Resultado";
            btn_Resultado.UseVisualStyleBackColor = true;
            btn_Resultado.Click += btn_Resultado_Click;
            // 
            // btn_ListaNotas
            // 
            btn_ListaNotas.Location = new System.Drawing.Point(20, 262);
            btn_ListaNotas.Name = "btn_ListaNotas";
            btn_ListaNotas.Size = new System.Drawing.Size(212, 34);
            btn_ListaNotas.TabIndex = 8;
            btn_ListaNotas.Text = "&Limpiar lista de Notas";
            btn_ListaNotas.UseVisualStyleBackColor = true;
            btn_ListaNotas.Click += btn_ListaNotas_Click;
            // 
            // btn_EliminarSelec
            // 
            btn_EliminarSelec.Location = new System.Drawing.Point(20, 174);
            btn_EliminarSelec.Name = "btn_EliminarSelec";
            btn_EliminarSelec.Size = new System.Drawing.Size(212, 34);
            btn_EliminarSelec.TabIndex = 7;
            btn_EliminarSelec.Text = "&Eliminar Seleccionado";
            btn_EliminarSelec.UseVisualStyleBackColor = true;
            btn_EliminarSelec.Click += btn_EliminarSelec_Click;
            // 
            // txt_NotaSeleccionada
            // 
            txt_NotaSeleccionada.Enabled = false;
            txt_NotaSeleccionada.Location = new System.Drawing.Point(294, 121);
            txt_NotaSeleccionada.Name = "txt_NotaSeleccionada";
            txt_NotaSeleccionada.Size = new System.Drawing.Size(112, 31);
            txt_NotaSeleccionada.TabIndex = 6;
            // 
            // lbl_NotasSelec
            // 
            lbl_NotasSelec.AutoSize = true;
            lbl_NotasSelec.Location = new System.Drawing.Point(20, 121);
            lbl_NotasSelec.Name = "lbl_NotasSelec";
            lbl_NotasSelec.Size = new System.Drawing.Size(158, 25);
            lbl_NotasSelec.TabIndex = 5;
            lbl_NotasSelec.Text = "Nota Seleccionada";
            // 
            // btn_Add
            // 
            btn_Add.Location = new System.Drawing.Point(294, 45);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new System.Drawing.Size(112, 34);
            btn_Add.TabIndex = 3;
            btn_Add.Text = "&Agregar";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(20, 53);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(118, 25);
            label1.TabIndex = 1;
            label1.Text = "Digite la nota";
            // 
            // txtNota
            // 
            txtNota.Location = new System.Drawing.Point(144, 48);
            txtNota.MaxLength = 3;
            txtNota.Name = "txtNota";
            txtNota.Size = new System.Drawing.Size(113, 31);
            txtNota.TabIndex = 0;
            // 
            // btn_Salir
            // 
            btn_Salir.Location = new System.Drawing.Point(561, 500);
            btn_Salir.Name = "btn_Salir";
            btn_Salir.Size = new System.Drawing.Size(159, 34);
            btn_Salir.TabIndex = 11;
            btn_Salir.Text = "&Salir";
            btn_Salir.UseVisualStyleBackColor = true;
            btn_Salir.Click += btn_Salir_Click;
            // 
            // Frm_RegistroNotas
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.Control;
            ClientSize = new System.Drawing.Size(800, 559);
            Controls.Add(btn_Salir);
            Controls.Add(groupBox1);
            Name = "Frm_RegistroNotas";
            Text = "Registro de Notas";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNota;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Label lbl_NotasSelec;
        private System.Windows.Forms.TextBox txt_NotaSeleccionada;
        private System.Windows.Forms.Button btn_Resultado;
        private System.Windows.Forms.Button btn_ListaNotas;
        private System.Windows.Forms.Button btn_EliminarSelec;
        private System.Windows.Forms.Button btn_Salir;
        private System.Windows.Forms.Label lbl_Promedio;
        private System.Windows.Forms.ListView lista_Notas;
    }
}
